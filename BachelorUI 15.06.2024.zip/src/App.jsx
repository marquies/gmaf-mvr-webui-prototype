import React, { Component } from 'react';
import Navbar from "./components/navbar";
import Presentation from './components/presentation';
import Query from './components/query';
import "C:/Users/janmi/Desktop/Bachelorarbeit/Praxis/View/webview/node_modules/bootstrap/dist/css/bootstrap.min.css";


class App extends Component {

    constructor() {
        super()
        this.state = {
          queryresults:[]
        }      

        this.queryChanged= this.queryChanged.bind(this);
    } 

    async queryChanged(event) {

        //Collect Query Data
        //var text= document.getElementById("query-textarea").value;

        document.getElementById("loading-spinner").style.display="block";

        //Get Query Result from API
        var data= {"sdsd": "sdsds"}
        try {
            const response = await fetch("https://httpbin.org/post", {
              method: "POST", 
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(data),
            });
        
            const result = await response.json();

            console.log("Success:", result);
            //Go on here
            var queryresults =[
                {videoid:0, link:"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    playbacks:[{videoid:0, value:70, playbacksecond:120}, {videoid:0, value:60, playbacksecond:20},{videoid:0, value:30, playbacksecond:430}]
                },
                {videoid:1, link:"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                    playbacks:[{videoid:1, value:90, playbacksecond:10}, {videoid:1, value:60, playbacksecond:190},{videoid:1, value:50, playbacksecond:40}]
                 },
                 {videoid:2, link:"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                    playbacks:[{videoid:2, value:90, playbacksecond:180}, {videoid:2, value:60, playbacksecond:190},{videoid:2, value:50, playbacksecond:40}]
                 },
                 {videoid:3, link:"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                    playbacks:[{videoid:3, value:90, playbacksecond:250}, {videoid:3, value:60, playbacksecond:400},{videoid:3, value:50, playbacksecond:40}]
                 }
            ];
            
            this.setState({queryresults: queryresults})

            document.getElementById("loading-spinner").style.display="none";
     
          } catch (error) {
            console.error("Error:", error);
        }      
    }

    render() { 
        return <React.Fragment>
                <Navbar/>
                <div className='d-flex'>
                  <Query queryChanged={this.queryChanged}/>
                  <div id="loading-spinner" style={{"display": "none"}} className="spinner-grow" role="status">
                    <span className="sr-only">Loading...</span>
                  </div>
                  <Presentation queryresults={this.state.queryresults}/> 
                </div>  
                </React.Fragment>;
    }
}
 
export default App;