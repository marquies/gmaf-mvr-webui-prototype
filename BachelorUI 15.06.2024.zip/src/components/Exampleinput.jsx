import React, { Component } from 'react';

class Exampleinput extends Component {
    state = {  } 
    render() { 
        return <div></div>
    }
}
 
export default Exampleinput;