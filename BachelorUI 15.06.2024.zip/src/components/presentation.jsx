import React, { Component } from 'react';
import VideoCard from './videocard';

//Window where the app functions are displayed, changes content by clicking navbar
class Content extends Component {
    state = { 

    } 

    render() { 
        return <div id="presentation" className='d-flex mt-5' key="content"> 
        {this.props.queryresults.map((video, x) => (
                    <VideoCard key={x} videoid={video.videoid} link= {video.link} playbacks={video.playbacks}/>
                ))}
        </div>

        
                
    }
}
 
export default Content