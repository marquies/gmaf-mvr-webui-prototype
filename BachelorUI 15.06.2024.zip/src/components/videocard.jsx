import React, { Component } from 'react';
import JumpToButton from './jumptobutton';

class VideoCard extends Component {
    state = {  } 

    componentDidMount()
    {
        //if in order, this is the highest match. Start Playback there
        if(this.props.playbacks[0])
        {
            var startPlayBack= this.props.playbacks[0];
            var playbackvideo= document.getElementsByClassName("presentation-video")[startPlayBack.videoid];
    
            if (playbackvideo !=null)
            {
                playbackvideo.currentTime= startPlayBack.playbacksecond;
        
            }
        }
    }

    render() { 
            return <div className="card presentation-card"  key={this.props.videoid}>
                        <video src={this.props.link} className="card-img-top presentation-video" controls></video>
                        <div className="card-body">
                            <div className="d-flex">
                            {this.props.playbacks.map((playback, x) => (
                                <JumpToButton key={x} index={x} height={playback.value} value={playback.value} playbacksecond={playback.playbacksecond} videoid={playback.videoid}/>
                            ))}
                            </div>
                        </div>
                    </div>
    }
}
 
export default VideoCard;